def divide(first, second):
    if second == 0:
        from math import inf
        return inf
    else:
        result = first / second
        return result