def divide(first, second):
    if second == 0:
        return 'Ошибка'
    else:
        result = first / second
        return result
